import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Building2, Factory, GrapeIcon as Grain, Droplet, Shield, LeafyGreen, BarChart, Phone } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative bg-teal-900 text-white">
        <div className="container mx-auto px-4 py-20">
          <div className="flex flex-col items-center text-center max-w-3xl mx-auto gap-8">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Logo-AdBMzwDc0baBLq2XhelPDKM810E1Xw.png"
              alt="ECO PROW Logo"
              width={300}
              height={100}
              className="mb-8"
            />
            <h1 className="text-4xl md:text-5xl font-bold leading-tight">Innovative Dust Suppression Solutions</h1>
            <p className="text-xl text-teal-100">
              Enhancing operational efficiency and environmental safety in mining, construction, and agriculture
            </p>
            <Button className="bg-lime-500 hover:bg-lime-600 text-teal-900 font-semibold px-8 py-6 text-lg">
              Explore Solutions
            </Button>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-b from-transparent to-white"></div>
      </section>

      {/* Industries Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-teal-900 mb-12">Industries We Serve</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-2 border-teal-100 hover:border-lime-500 transition-colors">
              <CardHeader>
                <Factory className="w-12 h-12 text-lime-500 mb-4" />
                <CardTitle className="text-teal-900">Mining</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Effective control of airborne dust in open-pit mines, underground operations, and haul roads.
                </p>
              </CardContent>
            </Card>
            <Card className="border-2 border-teal-100 hover:border-lime-500 transition-colors">
              <CardHeader>
                <Building2 className="w-12 h-12 text-lime-500 mb-4" />
                <CardTitle className="text-teal-900">Construction</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Suppression of particulate emissions during site preparation, demolition, and material handling.
                </p>
              </CardContent>
            </Card>
            <Card className="border-2 border-teal-100 hover:border-lime-500 transition-colors">
              <CardHeader>
                <Grain className="w-12 h-12 text-lime-500 mb-4" />
                <CardTitle className="text-teal-900">Agriculture</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Reduction of dust during soil preparation, harvest activities, and storage operations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="bg-teal-50 py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-teal-900 mb-12">Key Benefits</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { icon: Droplet, title: "Improved Air Quality", desc: "Enhanced visibility and breathing conditions" },
              { icon: Shield, title: "Enhanced Safety", desc: "Protected workers and machinery" },
              { icon: LeafyGreen, title: "Eco-Friendly", desc: "Minimized environmental impact" },
              { icon: BarChart, title: "Efficiency", desc: "Optimized operational performance" },
            ].map((benefit, index) => (
              <div key={index} className="text-center">
                <benefit.icon className="w-12 h-12 text-lime-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-teal-900 mb-2">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-teal-900 mb-12">Our Solutions</h2>
          <div className="grid md:grid-cols-2 gap-12">
            <Card className="bg-gradient-to-br from-teal-900 to-teal-800 text-white">
              <CardHeader>
                <CardTitle className="text-2xl">Dust Suppression Solutions</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4">
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-lime-500 rounded-full mt-2"></div>
                    <span>Advanced polymer-based formulations</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-lime-500 rounded-full mt-2"></div>
                    <span>Long-lasting dust control effectiveness</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-lime-500 rounded-full mt-2"></div>
                    <span>Environmentally safe applications</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-teal-900 to-teal-800 text-white">
              <CardHeader>
                <CardTitle className="text-2xl">Construction & Mining Additives</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4">
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-lime-500 rounded-full mt-2"></div>
                    <span>High-performance superplasticizers</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-lime-500 rounded-full mt-2"></div>
                    <span>Advanced strength enhancers</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-lime-500 rounded-full mt-2"></div>
                    <span>Rapid-curing solutions</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-teal-900 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-teal-100 mb-8 max-w-2xl mx-auto">
            Contact our experts today to discover how our solutions can benefit your operations
          </p>
          <Button className="bg-lime-500 hover:bg-lime-600 text-teal-900 font-semibold px-8 py-6 text-lg">
            <Phone className="w-5 h-5 mr-2" />
            Contact Us Now
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-teal-950 text-teal-100 py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Logo-AdBMzwDc0baBLq2XhelPDKM810E1Xw.png"
                alt="ECO PROW Logo"
                width={150}
                height={50}
                className="mb-4"
              />
              <p className="text-sm">Leading provider of dust suppression and construction additives solutions.</p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-sm">
                <li>About Us</li>
                <li>Products</li>
                <li>Industries</li>
                <li>Contact</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Contact</h3>
              <ul className="space-y-2 text-sm">
                <li>info@ecoprow.com</li>
                <li>1-800-ECO-PROW</li>
                <li>123 Green Street</li>
                <li>Sustainability City, EC 12345</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Follow Us</h3>
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-teal-800 flex items-center justify-center">
                  <span className="sr-only">LinkedIn</span>
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
                  </svg>
                </div>
                <div className="w-10 h-10 rounded-full bg-teal-800 flex items-center justify-center">
                  <span className="sr-only">Twitter</span>
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
          <div className="border-t border-teal-800 mt-12 pt-8 text-center text-sm">
            <p>&copy; 2024 ECO PROW. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

