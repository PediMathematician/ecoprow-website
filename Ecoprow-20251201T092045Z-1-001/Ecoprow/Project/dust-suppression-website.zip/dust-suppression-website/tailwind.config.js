import { withTV } from "tailwind-variants"

export default withTV({
  content: ["./app/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        teal: {
          50: "#f0fdfa",
          100: "#ccfbf1",
          500: "#14b8a6",
          800: "#115e59",
          900: "#134e4a",
          950: "#042f2e",
        },
        lime: {
          500: "#84cc16",
          600: "#65a30d",
        },
      },
    },
  },
})

