import { ArrowRight, Droplets, Shield, Layers, Phone, Mail, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function Page() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative py-12 px-4 sm:px-6 lg:px-8 bg-[#008B9B]">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center md:items-start justify-between mb-12">
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Logo-NscnKuvXnMuczMFwVP9bRbvy3zPHt8.png"
              alt="Ecoprow Logo"
              className="h-12 md:h-16 mb-6 md:mb-0"
            />
            <Button className="bg-[#7AB51D] hover:bg-[#698F19] text-white">
              Get Started <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
          <div className="text-center md:text-left">
            <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl md:text-6xl">
              Comprehensive Solutions for
              <span className="text-[#7AB51D] block">Construction Challenges</span>
            </h1>
            <p className="mt-3 max-w-md mx-auto md:mx-0 text-base text-white/80 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
              Professional-grade solutions for mold removal, waterproofing, and screed materials. Trusted by
              construction professionals worldwide.
            </p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 bg-[#f8fdf5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {/* Mold Removers */}
            <Card className="relative overflow-hidden border-2 border-transparent hover:border-[#7AB51D] transition-all">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-6 w-6 text-[#008B9B]" />
                  Mold Removers
                </CardTitle>
                <CardDescription>Effective solutions for mold elimination and prevention</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-[#7AB51D] mr-2 flex-shrink-0" />
                    <span>Chemical-Based Mold Removers for severe infestations</span>
                  </li>
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-[#7AB51D] mr-2 flex-shrink-0" />
                    <span>Eco-Friendly enzyme cleaners for residential spaces</span>
                  </li>
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-[#7AB51D] mr-2 flex-shrink-0" />
                    <span>Preventive measures and monitoring solutions</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Waterproofing Solutions */}
            <Card className="relative overflow-hidden border-2 border-transparent hover:border-[#7AB51D] transition-all">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Droplets className="h-6 w-6 text-[#008B9B]" />
                  Waterproofing Solutions
                </CardTitle>
                <CardDescription>Complete protection against water damage</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-[#7AB51D] mr-2 flex-shrink-0" />
                    <span>Interior sealants and protective coatings</span>
                  </li>
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-[#7AB51D] mr-2 flex-shrink-0" />
                    <span>Exterior membrane systems and drainage solutions</span>
                  </li>
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-[#7AB51D] mr-2 flex-shrink-0" />
                    <span>Specialty waterproofing products and admixtures</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Screed Materials */}
            <Card className="relative overflow-hidden border-2 border-transparent hover:border-[#7AB51D] transition-all">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Layers className="h-6 w-6 text-[#008B9B]" />
                  Screed Materials
                </CardTitle>
                <CardDescription>Professional-grade flooring solutions</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-[#7AB51D] mr-2 flex-shrink-0" />
                    <span>Traditional sand-cement and self-leveling screeds</span>
                  </li>
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-[#7AB51D] mr-2 flex-shrink-0" />
                    <span>Fiber-reinforced options for high-traffic areas</span>
                  </li>
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-[#7AB51D] mr-2 flex-shrink-0" />
                    <span>Specialized solutions for specific requirements</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900">Ready to Get Started?</h2>
          <p className="mt-4 text-lg text-gray-500">
            Contact our team of experts for a personalized solution to your construction challenges.
          </p>
          <Button className="mt-8 bg-[#008B9B] hover:bg-[#007A88] text-white">
            Contact Us <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#7AB51D] text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="hover:underline">
                    Quotes and Orders
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Contact Sales
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Delivery Service
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Contact Service
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Information</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="hover:underline">
                    Returns
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Terms & Conditions
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    PAIA Manual
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Trading Hours
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Resources</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="hover:underline">
                    Find Us (Map Location)
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Call an Expert
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    FAQs
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Consumer Goods & Service
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
              <ul className="space-y-2">
                <li className="flex items-center">
                  <Mail className="h-5 w-5 mr-2" />
                  <a href="mailto:info@ecoprow.co.za" className="hover:underline">
                    info@ecoprow.co.za
                  </a>
                </li>
                <li className="flex items-center">
                  <Phone className="h-5 w-5 mr-2" />
                  <a href="tel:+27456-7890" className="hover:underline">
                    (+27) 456-7890
                  </a>
                </li>
                <li className="flex items-center">
                  <MapPin className="h-5 w-5 mr-2" />
                  <span>Find Us (Map Location)</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-white/20 text-center">
            <p>&copy; {new Date().getFullYear()} Ecoprow. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

