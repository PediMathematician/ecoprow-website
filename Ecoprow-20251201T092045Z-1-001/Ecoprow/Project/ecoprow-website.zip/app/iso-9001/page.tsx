import { Navbar } from "@/components/navbar"
import { ContactForm } from "@/components/contact-form"
import { Footer } from "@/components/footer"

export default function ISO9001() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <section className="bg-gradient-to-r from-[#007C91] to-[#006577] py-20 text-white">
          <div className="container mx-auto px-4">
            <h1 className="mb-6 text-4xl font-bold md:text-5xl">ISO 9001:2015</h1>
            <p className="max-w-2xl text-lg">
              Building excellence, mining trust. Partner in construction and mining success. Building trust, shaping
              progress so you can get certified with confidence.
            </p>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid gap-12 lg:grid-cols-2">
              <div>
                <h2 className="mb-6 text-3xl font-bold">Seamless collaboration</h2>
                <p className="mb-6">
                  Ecoprow has the tools to empower your team to collaborate in real-time. Whether on-site, across
                  multiple locations, or working remotely.
                </p>
                <p className="mb-6">
                  Instead of time-consuming in-person meetings, colleagues can share screens, exchange documents, join
                  virtual meetings, and stream high-quality video seamlessly.
                </p>
                <p>
                  Working towards achieving certifications more efficiently with enhanced productivity & provides
                  substantial cost savings throughout the lifespan of your management systems.
                </p>
              </div>
              <div>
                <h3 className="mb-6 text-2xl font-bold">Ecoprow 4 steps approach</h3>
                <ol className="space-y-4">
                  <li className="flex items-center space-x-4">
                    <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#7AB51D] text-white">
                      1
                    </span>
                    <span>Conduct GAP analysis</span>
                  </li>
                  <li className="flex items-center space-x-4">
                    <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#7AB51D] text-white">
                      2
                    </span>
                    <span>Action finding and documents</span>
                  </li>
                  <li className="flex items-center space-x-4">
                    <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#7AB51D] text-white">
                      3
                    </span>
                    <span>Conduct internal audits</span>
                  </li>
                  <li className="flex items-center space-x-4">
                    <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#7AB51D] text-white">
                      4
                    </span>
                    <span>Book a Date final assessment</span>
                  </li>
                </ol>
              </div>
            </div>
          </div>
        </section>

        <section className="bg-gray-50 py-16">
          <div className="container mx-auto px-4">
            <div className="mx-auto max-w-md">
              <h2 className="mb-8 text-center text-3xl font-bold">Speak to an Expert</h2>
              <ContactForm />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

