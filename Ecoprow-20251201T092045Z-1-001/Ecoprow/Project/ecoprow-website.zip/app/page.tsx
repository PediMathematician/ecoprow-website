import { Navbar } from "@/components/navbar"
import { ContactForm } from "@/components/contact-form"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function Home() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-[#007C91] to-[#006577] py-20 text-white">
          <div className="container mx-auto px-4 text-center">
            <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">Consulting SHEQ Services</h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg">
              Safety first, success always. Ensure all risks are managed so that your business continues to thrive and
              survive.
            </p>
            <Button asChild className="bg-[#7AB51D] text-white hover:bg-[#699C19]" size="lg">
              <Link href="#contact">Speak to an Expert</Link>
            </Button>
          </div>
        </section>

        {/* Services Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="mb-12 text-center text-3xl font-bold">Our Services</h2>
            <div className="grid gap-8 md:grid-cols-3">
              <div className="rounded-lg border p-6 shadow-sm">
                <h3 className="mb-4 text-xl font-semibold">OHSAS 18001/ISO 45001</h3>
                <p className="mb-4 text-gray-600">
                  Comprehensive occupational health and safety management systems certification support.
                </p>
                <Link href="/ohsas-18001" className="text-[#007C91] hover:text-[#006577]">
                  Learn more →
                </Link>
              </div>
              <div className="rounded-lg border p-6 shadow-sm">
                <h3 className="mb-4 text-xl font-semibold">ISO 14001:2015</h3>
                <p className="mb-4 text-gray-600">
                  Environmental management systems certification and compliance solutions.
                </p>
                <Link href="/iso-14001" className="text-[#007C91] hover:text-[#006577]">
                  Learn more →
                </Link>
              </div>
              <div className="rounded-lg border p-6 shadow-sm">
                <h3 className="mb-4 text-xl font-semibold">ISO 9001:2015</h3>
                <p className="mb-4 text-gray-600">
                  Quality management systems certification for construction and mining industries.
                </p>
                <Link href="/iso-9001" className="text-[#007C91] hover:text-[#006577]">
                  Learn more →
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="bg-gray-50 py-16">
          <div className="container mx-auto px-4">
            <div className="mx-auto max-w-md">
              <h2 className="mb-8 text-center text-3xl font-bold">Speak to an Expert</h2>
              <ContactForm />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

