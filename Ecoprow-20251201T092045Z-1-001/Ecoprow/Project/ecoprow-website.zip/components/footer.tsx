import Link from "next/link"

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-4">
          <div>
            <h3 className="mb-4 text-lg font-semibold">Information</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="hover:text-[#7AB51D]">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-[#7AB51D]">
                  Contact Sales
                </Link>
              </li>
              <li>
                <Link href="/locations" className="hover:text-[#7AB51D]">
                  Find Us
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-4 text-lg font-semibold">Services</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/ohsas-18001" className="hover:text-[#7AB51D]">
                  OHSAS 18001
                </Link>
              </li>
              <li>
                <Link href="/iso-14001" className="hover:text-[#7AB51D]">
                  ISO 14001:2015
                </Link>
              </li>
              <li>
                <Link href="/iso-9001" className="hover:text-[#7AB51D]">
                  ISO 9001:2015
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-4 text-lg font-semibold">Support</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/faqs" className="hover:text-[#7AB51D]">
                  FAQs
                </Link>
              </li>
              <li>
                <Link href="/contact-service" className="hover:text-[#7AB51D]">
                  Contact Service
                </Link>
              </li>
              <li>
                <Link href="/expert" className="hover:text-[#7AB51D]">
                  Call an Expert
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-4 text-lg font-semibold">Legal</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/terms" className="hover:text-[#7AB51D]">
                  Terms & Conditions
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-[#7AB51D]">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t border-gray-800 pt-8 text-center">
          <p>&copy; {new Date().getFullYear()} Ecoprow. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

