"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { Menu, X } from "lucide-react"

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="border-b bg-white">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Logo-lYnw81qkF03bLkIMSO2Ophi2PgtBtu.png"
              alt="Ecoprow Logo"
              width={150}
              height={50}
              className="h-auto w-auto"
            />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex md:items-center md:space-x-6">
            <Link href="/ohsas-18001" className="text-gray-700 hover:text-[#007C91]">
              OHSAS 18001
            </Link>
            <Link href="/iso-14001" className="text-gray-700 hover:text-[#007C91]">
              ISO 14001:2015
            </Link>
            <Link href="/iso-9001" className="text-gray-700 hover:text-[#007C91]">
              ISO 9001:2015
            </Link>
            <Button variant="default" className="bg-[#007C91] hover:bg-[#006577]">
              Speak to an Expert
            </Button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-gray-700">
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden">
            <div className="space-y-4 px-2 pb-3 pt-2">
              <Link href="/ohsas-18001" className="block rounded-md px-3 py-2 text-gray-700 hover:bg-gray-50">
                OHSAS 18001
              </Link>
              <Link href="/iso-14001" className="block rounded-md px-3 py-2 text-gray-700 hover:bg-gray-50">
                ISO 14001:2015
              </Link>
              <Link href="/iso-9001" className="block rounded-md px-3 py-2 text-gray-700 hover:bg-gray-50">
                ISO 9001:2015
              </Link>
              <Button variant="default" className="w-full bg-[#007C91] hover:bg-[#006577]">
                Speak to an Expert
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}

