export const colors = {
  primary: {
    green: "#7AB51D",
    blue: "#007C91",
  },
  text: {
    primary: "#333333",
    secondary: "#666666",
  },
  background: {
    light: "#FFFFFF",
    subtle: "#F9FAFB",
  },
}

