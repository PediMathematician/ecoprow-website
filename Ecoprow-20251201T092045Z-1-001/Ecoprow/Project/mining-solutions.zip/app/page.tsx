"use client"

import { WhyChooseUs } from "../components/why-choose-us"

export default function SyntheticV0PageForDeployment() {
  return <WhyChooseUs />
}