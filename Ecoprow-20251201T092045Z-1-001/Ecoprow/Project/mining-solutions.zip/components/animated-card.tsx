"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { ArrowRight } from "lucide-react"

interface AnimatedCardProps {
  title: string
  description: string
  features: string[]
  icon: React.ReactNode
}

export function AnimatedCard({ title, description, features, icon }: AnimatedCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <motion.div
      className="relative h-full bg-white rounded-xl overflow-hidden"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <div className="p-8">
        <div className="flex items-start gap-4">
          <div className="shrink-0">
            <div className="w-12 h-12 rounded-lg bg-brand-teal text-white flex items-center justify-center">{icon}</div>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-2">{title}</h3>
            <p className="text-gray-600 mb-4">{description}</p>
          </div>
        </div>
        <motion.div
          className="space-y-3"
          animate={{ height: isHovered ? "auto" : 0, opacity: isHovered ? 1 : 0 }}
          transition={{ duration: 0.3 }}
        >
          {features.map((feature, index) => (
            <div key={index} className="flex items-center gap-2 text-gray-600">
              <ArrowRight className="w-4 h-4 text-brand-teal" />
              <span>{feature}</span>
            </div>
          ))}
        </motion.div>
      </div>
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-brand-teal to-brand-green opacity-0"
        animate={{ opacity: isHovered ? 0.1 : 0 }}
        transition={{ duration: 0.3 }}
      />
    </motion.div>
  )
}

