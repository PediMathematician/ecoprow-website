"use client"

import { motion } from "framer-motion"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-gray-50 to-gray-100 -z-10" />
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              High-Performance Solutions for <span className="text-brand-teal">Underground Mining</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              We deliver specialized solutions designed to enhance safety, efficiency, and durability in challenging
              mining environments.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <button className="bg-brand-teal text-white px-8 py-3 rounded-md hover:bg-brand-teal/90 transition-colors">
                Explore Solutions
              </button>
              <button className="border-2 border-brand-teal text-brand-teal px-8 py-3 rounded-md hover:bg-brand-teal/10 transition-colors">
                Contact Us
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

