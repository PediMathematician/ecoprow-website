"use client"

import { motion } from "framer-motion"
import { Shield, Factory, CheckCircle } from "lucide-react"

export function Offerings() {
  const features = [
    {
      title: "High-Performance Cementitious Materials",
      icon: Shield,
      description: "Engineered for underground support systems, ensuring strength and durability in harsh conditions.",
      features: [
        "Rapid setting times for immediate support",
        "Superior adhesion to rock surfaces",
        "Enhanced durability to withstand high-stress environments",
      ],
    },
    {
      title: "Contract Manufacturing Services",
      icon: Factory,
      description:
        "Tailored contract manufacturing for mining operations, providing custom formulations and packaging.",
      features: [
        "Flexibility in product design",
        "High-quality production standards",
        "Reduced downtime and streamlined supply chain",
      ],
    },
  ]

  return (
    <section id="solutions" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Core Offerings</h2>
          <div className="h-1 w-20 bg-brand-green mx-auto"></div>
        </div>
        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="bg-gray-50 rounded-lg p-8 hover:shadow-lg transition-shadow"
            >
              <div className="inline-flex h-12 w-12 items-center justify-center rounded-lg bg-brand-teal text-white mb-6">
                <feature.icon size={24} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">{feature.title}</h3>
              <p className="text-gray-600 mb-6">{feature.description}</p>
              <ul className="space-y-3">
                {feature.features.map((item, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-brand-green shrink-0 mt-0.5" />
                    <span className="text-gray-600">{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

