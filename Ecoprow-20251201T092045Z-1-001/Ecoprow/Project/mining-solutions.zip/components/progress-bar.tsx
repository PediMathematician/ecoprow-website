"use client"

import { motion, useScroll, useTransform } from "framer-motion"
import { useRef } from "react"

interface ProgressBarProps {
  label: string
  value: number
}

export function ProgressBar({ label, value }: ProgressBarProps) {
  const ref = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end end"],
  })

  const scaleX = useTransform(scrollYProgress, [0, 1], [0, value / 100])

  return (
    <div ref={ref} className="mb-6">
      <div className="flex justify-between mb-2">
        <span className="text-sm font-medium text-gray-700">{label}</span>
        <span className="text-sm font-medium text-brand-teal">{value}%</span>
      </div>
      <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
        <motion.div
          className="h-full bg-gradient-to-r from-brand-teal to-brand-green"
          style={{ scaleX, transformOrigin: "left" }}
        />
      </div>
    </div>
  )
}

