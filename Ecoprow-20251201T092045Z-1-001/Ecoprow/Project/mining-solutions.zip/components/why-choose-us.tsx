import { Brain, Lightbulb, Settings } from "lucide-react"

export function WhyChooseUs() {
  return (
    <section id="why-us" className="bg-gray-50 py-24">
      <div className="container px-4">
        <div className="mb-16 text-center">
          <h2 className="mb-4 text-3xl font-bold text-gray-900">Why Choose Us</h2>
          <div className="mx-auto h-1 w-20 bg-secondary"></div>
        </div>
        <div className="grid gap-8 md:grid-cols-3">
          {[
            {
              icon: Brain,
              title: "Specialized Expertise",
              description: "Deep knowledge of underground mining requirements and challenges.",
            },
            {
              icon: Lightbulb,
              title: "Innovative Solutions",
              description: "Cutting-edge materials and manufacturing practices.",
            },
            {
              icon: Settings,
              title: "Customizability",
              description: "Solutions tailored to meet specific project demands.",
            },
          ].map((item, index) => (
            <div
              key={index}
              className="group rounded-lg bg-white p-6 text-center shadow-flat transition-transform hover:-translate-y-1"
            >
              <div className="mx-auto mb-6 inline-flex h-16 w-16 items-center justify-center rounded-lg bg-primary text-white">
                <item.icon className="h-8 w-8" />
              </div>
              <h3 className="mb-4 text-xl font-semibold">{item.title}</h3>
              <p className="text-gray-600">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

