"use client"

import { motion } from "framer-motion"
import { Brain, Lightbulb, Settings } from "lucide-react"

export function WhyUs() {
  const reasons = [
    {
      icon: Brain,
      title: "Specialized Expertise",
      description: "Deep knowledge of underground mining requirements and challenges.",
    },
    {
      icon: Lightbulb,
      title: "Innovative Solutions",
      description: "Cutting-edge materials and manufacturing practices.",
    },
    {
      icon: Settings,
      title: "Customizability",
      description: "Solutions tailored to meet specific project demands.",
    },
  ]

  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose Us</h2>
          <div className="h-1 w-20 bg-brand-green mx-auto"></div>
        </div>
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {reasons.map((reason, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-brand-teal text-white mb-6">
                <reason.icon size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">{reason.title}</h3>
              <p className="text-gray-600">{reason.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

