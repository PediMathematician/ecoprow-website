import { Navbar } from "./components/navbar"
import { Hero } from "./components/hero"
import { Offerings } from "./components/offerings"
import { WhyUs } from "./components/why-us"
import { Contact } from "./components/contact"
import { ParticlesBackground } from "./components/particles-background"
import { AnimatedCard } from "./components/animated-card"
import { ProgressBar } from "./components/progress-bar"
import { Shield, Factory } from "lucide-react"

export default function Home() {
  const offerings = [
    {
      title: "High-Performance Cementitious Materials",
      description: "Engineered for underground support systems, ensuring strength and durability in harsh conditions.",
      icon: <Shield className="w-6 h-6" />,
      features: [
        "Rapid setting times for immediate support",
        "Superior adhesion to rock surfaces",
        "Enhanced durability in high-stress environments",
      ],
    },
    {
      title: "Contract Manufacturing Services",
      description: "Tailored contract manufacturing for mining operations with custom formulations and packaging.",
      icon: <Factory className="w-6 h-6" />,
      features: [
        "Flexibility in product design",
        "High-quality production standards",
        "Streamlined supply chain management",
      ],
    },
  ]

  const capabilities = [
    { label: "Underground Support Systems", value: 95 },
    { label: "Custom Formulations", value: 90 },
    { label: "Quality Standards", value: 98 },
    { label: "Technical Expertise", value: 92 },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <ParticlesBackground />
      <Navbar />
      <Hero />

      <section id="offerings" className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Solutions</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {offerings.map((offering, index) => (
              <AnimatedCard key={index} {...offering} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Capabilities</h2>
          <div className="max-w-2xl mx-auto">
            {capabilities.map((capability, index) => (
              <ProgressBar key={index} {...capability} />
            ))}
          </div>
        </div>
      </section>

      <WhyUs />
      <Contact />
    </div>
  )
}

