import { type Config } from "tailwindcss"

export default {
  content: [],
  theme: {
    extend: {
      colors: {
        brand: {
          green: '#4CD964',
          teal: '#008B8B',
        },
        primary: {
          DEFAULT: '#008B8B',
          foreground: '#ffffff',
        },
        secondary: {
          DEFAULT: '#4CD964',
          foreground: '#ffffff',
        },
      },
      keyframes: {
        'slide-up': {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        }
      },
      animation: {
        'slide-up': 'slide-up 0.5s ease-out forwards',
      }
    },
  },
} satisfies Config

