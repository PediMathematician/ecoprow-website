import Link from "next/link"

export default function Footer() {
  return (
    <footer className="bg-[#008C95] text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-semibold mb-4 text-[#8DC63F]">Quotes and Orders</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/contact-sales" className="hover:text-[#8DC63F] transition-colors">
                  Contact Sales
                </Link>
              </li>
              <li>
                <Link href="/delivery-service" className="hover:text-[#8DC63F] transition-colors">
                  Delivery Service
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold mb-4 text-[#8DC63F]">Information</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about-us" className="hover:text-[#8DC63F] transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact-service" className="hover:text-[#8DC63F] transition-colors">
                  Contact Service
                </Link>
              </li>
              <li>
                <Link href="/returns" className="hover:text-[#8DC63F] transition-colors">
                  Returns
                </Link>
              </li>
              <li>
                <Link href="/terms-conditions" className="hover:text-[#8DC63F] transition-colors">
                  Terms & Conditions
                </Link>
              </li>
              <li>
                <Link href="/privacy-policy" className="hover:text-[#8DC63F] transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/paia-manual" className="hover:text-[#8DC63F] transition-colors">
                  PAIA Manual
                </Link>
              </li>
              <li>
                <Link href="/trading-hours" className="hover:text-[#8DC63F] transition-colors">
                  Trading Hours
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold mb-4 text-[#8DC63F]">Resources</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/find-us" className="hover:text-[#8DC63F] transition-colors">
                  Find Us (Map Location)
                </Link>
              </li>
              <li>
                <Link href="/call-expert" className="hover:text-[#8DC63F] transition-colors">
                  Call an Expert
                </Link>
              </li>
              <li>
                <Link href="/faqs" className="hover:text-[#8DC63F] transition-colors">
                  FAQs
                </Link>
              </li>
              <li>
                <Link href="/consumer-goods-service" className="hover:text-[#8DC63F] transition-colors">
                  Consumer Goods & Service
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold mb-4 text-[#8DC63F]">Contact Us</h3>
            <p className="mb-2">Email: info@ecoprow.co.za</p>
            <p>Phone: (+27) 456-7890</p>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-[#8DC63F]/20 text-center">
          <p>&copy; 2024 ECO PROW.CO.ZA All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

