import Image from "next/image"
import { Button } from "@/components/ui/button"
import Footer from "../components/footer"

export default function InstallationGuide() {
  return (
    <div className="min-h-screen flex flex-col">
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-6">Installation Guide</h1>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Preparation</h2>
          <ol className="list-decimal pl-5">
            <li>Clean and level the surface</li>
            <li>Gather necessary tools and materials</li>
            <li>Plan your tile layout</li>
          </ol>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Tile Installation Steps</h2>
          <ol className="list-decimal pl-5">
            <li>Apply adhesive to the surface</li>
            <li>Place tiles with correct spacing</li>
            <li>Allow adhesive to dry</li>
            <li>Apply grout between tiles</li>
            <li>Clean and seal the tiled surface</li>
          </ol>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Grouting Options</h2>
          <ul className="list-disc pl-5">
            <li>Sanded grout for wider joints</li>
            <li>Unsanded grout for narrow joints</li>
            <li>Epoxy grout for high-traffic areas</li>
          </ul>
        </section>

        <Button className="mb-8">Download Full Installation Manual (PDF)</Button>

        <section>
          <h2 className="text-2xl font-semibold mb-4">Need Professional Help?</h2>
          <Button>Call an Expert</Button>
        </section>
      </main>
      <Footer />
    </div>
  )
}

