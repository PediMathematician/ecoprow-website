import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "ECO PROW - Seamless Surface Solutions",
  description: "Professional tile adhesive and surface solutions",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <header className="border-b">
          <div className="container mx-auto px-4 py-4">
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Logo-zujg2aLiSzVUqyw5FbRYVVlfCUMcq8.png"
              alt="ECO PROW Logo"
              className="h-12 md:h-16"
            />
          </div>
        </header>
        {children}
      </body>
    </html>
  )
}

