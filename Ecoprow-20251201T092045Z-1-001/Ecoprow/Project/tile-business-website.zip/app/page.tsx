import Link from "next/link"
import { Button } from "@/components/ui/button"
import Footer from "./components/footer"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <main className="flex-grow">
        <section className="bg-gradient-to-br from-[#8DC63F] to-[#008C95] text-white">
          <div className="container mx-auto px-4 py-16 md:py-24">
            <div className="max-w-3xl">
              <h1 className="text-4xl md:text-6xl font-bold mb-6">Professional Tile Adhesive Solutions</h1>
              <p className="text-xl mb-8">Super fast, easy application perfect for ceramic tiles</p>
              <Button className="bg-white text-[#008C95] hover:bg-gray-100" size="lg">
                Explore Products
              </Button>
            </div>
          </div>
        </section>

        <section className="container mx-auto px-4 py-16">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Ceramic%20front%20page.jpg-R00JQIOXMjRZw6u79ofkWKZQ3PivwF.jpeg"
                alt="ECO PROW Tile Adhesive"
                className="rounded-lg shadow-lg"
              />
            </div>
            <div>
              <h2 className="text-3xl font-bold mb-6 text-[#008C95]">24 Hours Super Fast Setting</h2>
              <ul className="space-y-4">
                <li className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-[#8DC63F] flex items-center justify-center">
                    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-lg">Easy Application</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-[#8DC63F] flex items-center justify-center">
                    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                  </div>
                  <span className="text-lg">24 Hour Setting Time</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-[#8DC63F] flex items-center justify-center">
                    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                  </div>
                  <span className="text-lg">Perfect for Ceramic Tiles</span>
                </li>
              </ul>
            </div>
          </div>
        </section>

        <section className="bg-gray-50 py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-[#008C95]">Our Services</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-4 text-[#008C95]">Professional Installation</h3>
                <p className="text-gray-600">Expert installation services by certified professionals</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-4 text-[#008C95]">Technical Support</h3>
                <p className="text-gray-600">Comprehensive support for all your tiling needs</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-4 text-[#008C95]">Product Training</h3>
                <p className="text-gray-600">Learn how to use our products effectively</p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

