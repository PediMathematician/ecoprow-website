import Image from "next/image"
import Footer from "../components/footer"

export default function Products() {
  return (
    <div className="min-h-screen flex flex-col">
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-6">Our Products</h1>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Tiles</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-xl font-medium mb-2">Ceramic Tiles</h3>
              <p>Durable and versatile, perfect for various applications.</p>
            </div>
            <div>
              <h3 className="text-xl font-medium mb-2">Porcelain Tiles</h3>
              <p>High-quality, low-maintenance tiles for a luxurious finish.</p>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Adhesives</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-xl font-medium mb-2">Porcelain Adhesive</h3>
              <p>Specially formulated for porcelain tiles. High bond strength and flexibility.</p>
              <p className="mt-2 font-semibold">Product Spec: XYZ-100</p>
            </div>
            <div>
              <h3 className="text-xl font-medium mb-2">Ceramic Adhesive</h3>
              <p>Ideal for ceramic tiles. Easy to apply and quick-setting.</p>
              <p className="mt-2 font-semibold">Product Spec: ABC-200</p>
            </div>
          </div>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">How to Use Our Products</h2>
          <div className="aspect-w-16 aspect-h-9">
            <iframe
              src="https://www.youtube.com/embed/dQw4w9WgXcQ"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full"
            ></iframe>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

