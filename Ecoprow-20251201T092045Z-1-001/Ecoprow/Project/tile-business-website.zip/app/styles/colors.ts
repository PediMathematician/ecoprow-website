export const colors = {
  primary: {
    DEFAULT: "#8DC63F", // Lime green
    foreground: "#FFFFFF",
  },
  secondary: {
    DEFAULT: "#008C95", // Teal
    foreground: "#FFFFFF",
  },
  background: "#FFFFFF",
}

